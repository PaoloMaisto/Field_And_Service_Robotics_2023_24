function v = vec(m)

v = reshape(m,[numel(m),1]);

end